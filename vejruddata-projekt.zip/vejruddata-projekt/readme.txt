Dette projekt er et lille Python-projekt, hvor vi analyserer og visualiserer vejruddata.  

Hvad projektet gør
- Læser daglige temperatur- og nedbørsdata fra en CSV
- Beregner statistik som gennemsnit, standardafvigelse og korrelation
- Laver plots:
  - Temperatur over tid
  - Histogram af temperatur
  - Scatter plot af temperatur vs nedbør


